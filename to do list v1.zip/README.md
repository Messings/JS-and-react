Simple  my todo list creted with TS v1. 
A todo list where you can manually add new things to do.
Has weak delete and edit functionality and bad design that will be expanded upon in later versions.